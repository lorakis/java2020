package obliczenia;

public interface Obliczalny
{
  int oblicz();
}
